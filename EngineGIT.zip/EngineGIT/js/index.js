function connectFB() {
    var config = {
        apiKey: "AIzaSyDrVZ3499rhvfFpxfRbU-wqJ-ZUN0-_ez0",
        authDomain: "cremeria-imperial.firebaseapp.com",
        databaseURL: "https://cremeria-imperial.firebaseio.com",
        projectId: "cremeria-imperial",
        storageBucket: "cremeria-imperial.appspot.com",
        messagingSenderId: "445465872507"
    };

    return config;
}